type User = {
  id: String
}
