export invalid = "apple" < "banana"
