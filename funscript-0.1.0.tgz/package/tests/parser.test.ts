import { describe, it, expect } from "vitest";
import { Lexer } from "../src/lexer/lexer.js";
import { Parser, ParseError } from "../src/parser/parser.js";
import {
  Program,
  ImportDeclaration,
  ExportDeclaration,
  ExportDefaultDeclaration,
  SchemaDeclaration,
  RecordSchema,
  TaggedUnionSchema,
  RefinementSchema,
  TypeSignatureSchema,
  TsDerivedSchema,
  ImportedTsSchema,
  TypeReferenceNode,
  ErrorDeclaration,
  ServiceDeclaration,
  BindingDeclaration,
  BinaryExpression,
  UnaryExpression,
  PipelineExpression,
  CallExpression,
  MemberExpression,
  IndexExpression,
  RecordExpression,
  ArrayExpression,
    FunctionExpression,
  FunctionTypeNode,
  EffectTypeNode,
  BlockStatement,
  MutBlockExpression,
  MatchExpression,
  EffectBlockExpression,
  EffectBindStatement,
  EffectDiscardStatement,
  TypedHole,
  ConstructorPattern,
  LiteralPattern,
  VariablePattern,
  WildcardPattern,
  OrPattern,
} from "../src/ast/types.js";

function parse(source: string, filename = "test.fun"): Program {
  const lexer = new Lexer(source, filename);
  const parser = new Parser(lexer.tokenize(), filename);
  return parser.parse();
}

describe("FunScript Parser", () => {
  describe("Import & Export Declarations", () => {
    it("parses standard and aliased imports", () => {
      const ast = parse(`import { User, Config as AppConfig } from "./config.js"`);
      expect(ast.body.length).toBe(1);

      const imp = ast.body[0] as ImportDeclaration;
      expect(imp.kind).toBe("ImportDeclaration");
      expect(imp.isTypeOnly).toBe(false);
      expect(imp.source.parts[0]).toEqual({ kind: "StringRawPart", value: "./config.js" });
      expect(imp.specifiers.length).toBe(2);

      expect(imp.specifiers[0].imported.name).toBe("User");
      expect(imp.specifiers[0].local.name).toBe("User");
      expect(imp.specifiers[0].isTypeOnly).toBe(false);

      expect(imp.specifiers[1].imported.name).toBe("Config");
      expect(imp.specifiers[1].local.name).toBe("AppConfig");
      expect(imp.specifiers[1].isTypeOnly).toBe(false);
    });

    it("parses multiple imports", () => {
      const ast = parse(`import { State } from "./state.js"\nimport { client, Config } from "./api.js"`);
      expect(ast.body.length).toBe(2);

      const imp1 = ast.body[0] as ImportDeclaration;
      expect(imp1.kind).toBe("ImportDeclaration");
      expect(imp1.specifiers[0].imported.name).toBe("State");

      const imp2 = ast.body[1] as ImportDeclaration;
      expect(imp2.kind).toBe("ImportDeclaration");
      expect(imp2.specifiers.length).toBe(2);
      expect(imp2.specifiers[0].imported.name).toBe("client");
      expect(imp2.specifiers[1].imported.name).toBe("Config");
    });

    it("parses exported declarations", () => {
      const ast = parse(`
export schema Item = { id: String }
export count = 10
`);
      expect(ast.body.length).toBe(2);
      expect(ast.body[0].kind).toBe("ExportDeclaration");
      expect((ast.body[0] as ExportDeclaration).declaration.kind).toBe("SchemaDeclaration");

      expect(ast.body[1].kind).toBe("ExportDeclaration");
      expect((ast.body[1] as ExportDeclaration).declaration.kind).toBe("BindingDeclaration");
    });

    it("parses export default declarations", () => {
      const ast = parse("export default App");
      expect(ast.body.length).toBe(1);
      const decl = ast.body[0] as ExportDefaultDeclaration;
      expect(decl.kind).toBe("ExportDefaultDeclaration");
      expect(decl.expression.kind).toBe("UpperIdentifier");
      expect((decl.expression as any).name).toBe("App");
    });

    it("parses export default with arrow function and JSX in funx", () => {
      const ast = parse("export default () => <div />", "test.funx");
      expect(ast.body.length).toBe(1);
      const decl = ast.body[0] as ExportDefaultDeclaration;
      expect(decl.kind).toBe("ExportDefaultDeclaration");
      expect(decl.expression.kind).toBe("FunctionExpression");
    });

    it("parses export default with literal expression", () => {
      const ast = parse("export default 42");
      expect(ast.body.length).toBe(1);
      const decl = ast.body[0] as ExportDefaultDeclaration;
      expect(decl.kind).toBe("ExportDefaultDeclaration");
      expect(decl.expression.kind).toBe("NumberLiteral");
    });

    it("rejects multiple export default declarations in one file", () => {
      expect(() => parse("export default 1\nexport default 2")).toThrowError(
        /Multiple default exports are not allowed/
      );
    });
  });

  describe("Schema Declarations", () => {
    it("parses RecordSchema with required fields and default values", () => {
      const ast = parse(`
schema User = {
  id: String
  name: String
  role: String = "member"
  age: Number
}
`);
      expect(ast.body.length).toBe(1);
      const decl = ast.body[0] as SchemaDeclaration;
      expect(decl.kind).toBe("SchemaDeclaration");
      expect(decl.id.name).toBe("User");

      const body = decl.body as RecordSchema;
      expect(body.kind).toBe("RecordSchema");
      expect(body.fields.length).toBe(4);

      expect(body.fields[0].name.name).toBe("id");
      expect(body.fields[0].typeAnnotation.kind).toBe("TypeReferenceNode");
      expect(body.fields[0].defaultValue).toBeUndefined();

      expect(body.fields[2].name.name).toBe("role");
      expect(body.fields[2].defaultValue?.kind).toBe("StringLiteral");
    });

    it("parses TaggedUnionSchema with variants, fields, and unit variants", () => {
      const ast = parse(`
schema Shape =
  | Circle(radius: Number)
  | Rect(width: Number, height: Number)
  | Point
`);
      const decl = ast.body[0] as SchemaDeclaration;
      expect(decl.id.name).toBe("Shape");

      const body = decl.body as TaggedUnionSchema;
      expect(body.kind).toBe("TaggedUnionSchema");
      expect(body.variants.length).toBe(3);

      expect(body.variants[0].name.name).toBe("Circle");
      expect(body.variants[0].fields.length).toBe(1);
      expect(body.variants[0].fields[0].name.name).toBe("radius");

      expect(body.variants[1].name.name).toBe("Rect");
      expect(body.variants[1].fields.length).toBe(2);
      expect(body.variants[1].fields[0].name.name).toBe("width");
      expect(body.variants[1].fields[1].name.name).toBe("height");

      expect(body.variants[2].name.name).toBe("Point");
      expect(body.variants[2].fields.length).toBe(0);
    });

    it("parses schema with type parameters", () => {
      const ast = parse(`
schema Result<T, E> =
  | Ok(value: T)
  | Err(err: E)
`);
      const decl = ast.body[0] as SchemaDeclaration;
      expect(decl.id.name).toBe("Result");
      expect(decl.typeParams?.map((p) => p.name.name)).toEqual(["T", "E"]);

      const body = decl.body as TaggedUnionSchema;
      expect(body.variants.length).toBe(2);
      expect(body.variants[0].name.name).toBe("Ok");
      expect(body.variants[1].name.name).toBe("Err");
    });

    it("parses RefinementSchema", () => {
      const ast = parse(`schema Positive = Number |> Number.isGreaterThan(0)`);
      const decl = ast.body[0] as SchemaDeclaration;
      expect(decl.id.name).toBe("Positive");

      const body = decl.body as RefinementSchema;
      expect(body.kind).toBe("RefinementSchema");
      expect(body.baseType.kind).toBe("TypeReferenceNode");
      expect(body.refinement.kind).toBe("CallExpression");
    });

    it("parses schema with nested record types and complex types", () => {
      const ast = parse(`
schema ServerConfig = {
  host: String
  port: Number
  db: {
    url: String
    poolSize: Number
  }
}
`);
      const decl = ast.body[0] as SchemaDeclaration;
      const body = decl.body as RecordSchema;
      expect(body.fields.length).toBe(3);
      expect(body.fields[2].name.name).toBe("db");
      expect(body.fields[2].typeAnnotation.kind).toBe("RecordTypeNode");
    });

    it("parses schema with Effect types including error and requirements channels", () => {
      const ast = parse(`
schema Action = (id: String) => Effect<User, NotFound, Database>
`);
      const decl = ast.body[0] as SchemaDeclaration;
      const body = decl.body as TypeSignatureSchema;
      expect(body.kind).toBe("TypeSignatureSchema");
      const sig = body.signature as FunctionTypeNode;
      expect(sig.returnType.kind).toBe("EffectTypeNode");
      const eff = sig.returnType as EffectTypeNode;
      expect(eff.success.kind).toBe("TypeReferenceNode");
      expect(eff.error?.kind).toBe("TypeReferenceNode");
      expect(eff.requirements?.kind).toBe("TypeReferenceNode");
    });

    it("parses ts schema declaration modifier syntax", () => {
      const ast = parse(`ts schema User = UserType`);
      expect(ast.body.length).toBe(1);
      const decl = ast.body[0] as SchemaDeclaration;
      expect(decl.kind).toBe("SchemaDeclaration");
      expect(decl.isTs).toBe(true);
      expect(decl.id.name).toBe("User");
      expect(decl.body.kind).toBe("TsDerivedSchema");
      const derived = decl.body as TsDerivedSchema;
      expect(derived.targetType.kind).toBe("TypeReferenceNode");
      expect((derived.targetType as any).name.name).toBe("UserType");
    });

    it("parses export ts schema with generic type arguments", () => {
      const ast = parse(`export ts schema User = UserType<String>`);
      expect(ast.body.length).toBe(1);
      const exp = ast.body[0] as ExportDeclaration;
      expect(exp.kind).toBe("ExportDeclaration");
      const decl = exp.declaration as SchemaDeclaration;
      expect(decl.kind).toBe("SchemaDeclaration");
      expect(decl.isTs).toBe(true);
      expect(decl.id.name).toBe("User");
      expect(decl.body.kind).toBe("TsDerivedSchema");
      const derived = decl.body as TsDerivedSchema;
      expect(derived.targetType.kind).toBe("TypeReferenceNode");
      expect((derived.targetType as any).typeArgs?.length).toBe(1);
      expect((derived.targetType as any).typeArgs[0].name.name).toBe("String");
    });

    it("parses ts schema with struct and array types", () => {
      const ast = parse(`
ts schema Config = { timeout: Number }
export ts schema Users = Array<UserType>
`);
      expect(ast.body.length).toBe(2);

      const decl1 = ast.body[0] as SchemaDeclaration;
      expect(decl1.isTs).toBe(true);
      expect(decl1.id.name).toBe("Config");
      expect(decl1.body.kind).toBe("TsDerivedSchema");
      expect((decl1.body as TsDerivedSchema).targetType.kind).toBe("RecordTypeNode");

      const exp2 = ast.body[1] as ExportDeclaration;
      const decl2 = exp2.declaration as SchemaDeclaration;
      expect(decl2.isTs).toBe(true);
      expect(decl2.id.name).toBe("Users");
      expect(decl2.body.kind).toBe("TsDerivedSchema");
      expect((decl2.body as TsDerivedSchema).targetType.kind).toBe("TypeReferenceNode");
    });

    it("parses ImportedTsSchema declarations from ts<Type>", () => {
      const ast = parse(`schema User = from ts<UserType>`);
      expect(ast.body.length).toBe(1);
      const decl = ast.body[0] as SchemaDeclaration;
      expect(decl.kind).toBe("SchemaDeclaration");
      expect(decl.id.name).toBe("User");

      const body = decl.body as ImportedTsSchema;
      expect(body.kind).toBe("ImportedTsSchema");
      expect(body.typeNode.kind).toBe("TypeReferenceNode");
      expect((body.typeNode as TypeReferenceNode).name.name).toBe("UserType");
      expect(body.typeArgs.length).toBe(1);
      expect(body.typeArguments.length).toBe(1);
      expect(body.typeArgs[0]).toBe(body.typeNode);
      expect(body.span.start.offset).toBe(14); // start of 'from'
      expect(body.span.end.offset).toBe(31); // end of '>'
    });

    it("parses ImportedTsSchema with type parameters and generic type arguments", () => {
      const ast = parse(`schema Container<T> = from ts<TargetType<T>>`);
      const decl = ast.body[0] as SchemaDeclaration;
      expect(decl.id.name).toBe("Container");
      expect(decl.typeParams?.length).toBe(1);
      expect(decl.typeParams?.[0].name.name).toBe("T");

      const body = decl.body as ImportedTsSchema;
      expect(body.kind).toBe("ImportedTsSchema");
      const ref = body.typeNode as TypeReferenceNode;
      expect(ref.name.name).toBe("TargetType");
      expect(ref.typeArgs?.length).toBe(1);
      expect((ref.typeArgs?.[0] as TypeReferenceNode).name.name).toBe("T");
    });

    it("parses exported ImportedTsSchema", () => {
      const ast = parse(`export schema User = from ts<UserType>`);
      const exp = ast.body[0] as ExportDeclaration;
      expect(exp.kind).toBe("ExportDeclaration");
      const decl = exp.declaration as SchemaDeclaration;
      expect(decl.kind).toBe("SchemaDeclaration");
      expect(decl.id.name).toBe("User");
      expect(decl.body.kind).toBe("ImportedTsSchema");
    });

    it("parses ImportedTsSchema with multiple type arguments", () => {
      const ast = parse(`schema Mapping = from ts<SourceType, TargetType>`);
      const decl = ast.body[0] as SchemaDeclaration;
      const body = decl.body as ImportedTsSchema;
      expect(body.kind).toBe("ImportedTsSchema");
      expect(body.typeArguments.length).toBe(2);
      expect((body.typeArguments[0] as TypeReferenceNode).name.name).toBe("SourceType");
      expect((body.typeArguments[1] as TypeReferenceNode).name.name).toBe("TargetType");
    });
  });

  describe("Error Declarations", () => {
    it("parses ErrorDeclaration with fields", () => {
      const ast = parse(`error NotFound(id: String, code: Number)`);
      const err = ast.body[0] as ErrorDeclaration;

      expect(err.kind).toBe("ErrorDeclaration");
      expect(err.id.name).toBe("NotFound");
      expect(err.fields.length).toBe(2);
      expect(err.fields[0].name.name).toBe("id");
      expect(err.fields[1].name.name).toBe("code");
    });

    it("parses ErrorDeclaration without fields", () => {
      const ast = parse(`error Unauthorized`);
      const err = ast.body[0] as ErrorDeclaration;

      expect(err.kind).toBe("ErrorDeclaration");
      expect(err.id.name).toBe("Unauthorized");
      expect(err.fields.length).toBe(0);
    });
  });

  describe("Service Declarations", () => {
    it("parses ServiceDeclaration with members and default tag", () => {
      const ast = parse(`
service UserRepo
  find: (id: String) => Effect<User, NotFound>
  save: (user: User) => Effect<Void>
`);
      const svc = ast.body[0] as ServiceDeclaration;

      expect(svc.kind).toBe("ServiceDeclaration");
      expect(svc.id.name).toBe("UserRepo");
      expect(svc.customTag).toBeUndefined();
      expect(svc.members.length).toBe(2);

      expect(svc.members[0].name.name).toBe("find");
      expect(svc.members[0].signature.kind).toBe("FunctionTypeNode");
      expect(svc.members[1].name.name).toBe("save");
    });

    it("parses ServiceDeclaration with custom tag string", () => {
      const ast = parse(`
service PaymentGateway "custom/payment/gateway"
  charge: (amount: Number) => Effect<Receipt, PaymentFailed>
`);
      const svc = ast.body[0] as ServiceDeclaration;

      expect(svc.kind).toBe("ServiceDeclaration");
      expect(svc.id.name).toBe("PaymentGateway");
      expect(svc.customTag?.parts[0]).toEqual({ kind: "StringRawPart", value: "custom/payment/gateway" });
      expect(svc.members.length).toBe(1);
      expect(svc.members[0].name.name).toBe("charge");
    });
  });

  describe("Retired 'extern' Keyword", () => {
    it("rejects 'extern' with an actionable migration error", () => {
      expect(() => parse(`extern "stripe" service StripeClient`)).toThrow(
        /FunScript has retired 'extern service'/
      );
    });
  });

  describe("Binding Declarations", () => {
    it("parses immutable, typed, and mutable bindings", () => {
      const ast = parse(`
x = 10
count: Number = 0
mut total = 100
mut flag: Boolean = true
`);
      expect(ast.body.length).toBe(4);

      const b0 = ast.body[0] as BindingDeclaration;
      expect(b0.isMut).toBe(false);
      expect(b0.id.name).toBe("x");
      expect(b0.typeAnnotation).toBeUndefined();

      const b1 = ast.body[1] as BindingDeclaration;
      expect(b1.isMut).toBe(false);
      expect(b1.id.name).toBe("count");
      expect(b1.typeAnnotation?.kind).toBe("TypeReferenceNode");

      const b2 = ast.body[2] as BindingDeclaration;
      expect(b2.isMut).toBe(true);
      expect(b2.id.name).toBe("total");

      const b3 = ast.body[3] as BindingDeclaration;
      expect(b3.isMut).toBe(true);
      expect(b3.id.name).toBe("flag");
      expect(b3.typeAnnotation?.kind).toBe("TypeReferenceNode");
    });
  });

  describe("Expressions & Precedence", () => {
    it("respects operator precedence for arithmetic", () => {
      const ast = parse(`res = 1 + 2 * 3`);
      const binding = ast.body[0] as BindingDeclaration;
      const bin = binding.init as BinaryExpression;

      expect(bin.kind).toBe("BinaryExpression");
      expect(bin.operator).toBe("+");
      expect(bin.left.kind).toBe("NumberLiteral");

      const right = bin.right as BinaryExpression;
      expect(right.kind).toBe("BinaryExpression");
      expect(right.operator).toBe("*");
    });

    it("groups multiplication on both sides of addition", () => {
      const ast = parse(`res = 1 * 2 + 3 * 4`);
      const addition = (ast.body[0] as BindingDeclaration).init as BinaryExpression;

      expect(addition.operator).toBe("+");
      expect((addition.left as BinaryExpression).operator).toBe("*");
      expect((addition.right as BinaryExpression).operator).toBe("*");
    });

    it("parses right-associative exponentiation", () => {
      const ast = parse(`res = 2 ** 3 ** 4`);
      const binding = ast.body[0] as BindingDeclaration;
      const bin = binding.init as BinaryExpression;

      expect(bin.operator).toBe("**");
      expect(bin.left.kind).toBe("NumberLiteral");
      // 2 ** (3 ** 4)
      expect(bin.right.kind).toBe("BinaryExpression");
      const right = bin.right as BinaryExpression;
      expect(right.operator).toBe("**");
      expect(right.left.kind).toBe("NumberLiteral");
      expect(right.right.kind).toBe("NumberLiteral");
    });

    it("parses subtraction as left-associative", () => {
      const ast = parse(`res = 10 - 3 - 2`);
      const binding = ast.body[0] as BindingDeclaration;
      const bin = binding.init as BinaryExpression;

      // (10 - 3) - 2
      expect(bin.operator).toBe("-");
      expect(bin.left.kind).toBe("BinaryExpression");
      const left = bin.left as BinaryExpression;
      expect(left.operator).toBe("-");
      expect(left.left.kind).toBe("NumberLiteral");
      expect(left.right.kind).toBe("NumberLiteral");
      expect(bin.right.kind).toBe("NumberLiteral");
    });

    it("parses logical and equality expressions", () => {
      const ast = parse(`res = a and b or c #= d #! e`);
      const binding = ast.body[0] as BindingDeclaration;
      expect(binding.init.kind).toBe("BinaryExpression");
    });

    it("binds and more tightly than or", () => {
      const ast = parse(`res = ready and valid or fallback and forced`);
      const root = (ast.body[0] as BindingDeclaration).init as BinaryExpression;

      expect(root.operator).toBe("or");
      expect((root.left as BinaryExpression).operator).toBe("and");
      expect((root.right as BinaryExpression).operator).toBe("and");
    });

    it("parses numeric comparisons between equality and arithmetic precedence", () => {
      const ast = parse(`res = 1 + 2 * 3 < 8 and 4 >= 4`);
      const binding = ast.body[0] as BindingDeclaration;
      const logical = binding.init as BinaryExpression;
      expect(logical.operator).toBe("and");
      expect((logical.left as BinaryExpression).operator).toBe("<");
      expect(((logical.left as BinaryExpression).left as BinaryExpression).operator).toBe("+");
      expect((logical.right as BinaryExpression).operator).toBe(">=");
    });

    it("binds numeric comparisons more tightly than value equality", () => {
      const ast = parse(`res = 1 < 2 #= 3 >= 4`);
      const binding = ast.body[0] as BindingDeclaration;
      const equality = binding.init as BinaryExpression;

      expect(equality.operator).toBe("#=");
      expect((equality.left as BinaryExpression).operator).toBe("<");
      expect((equality.right as BinaryExpression).operator).toBe(">=");
    });

    it("binds numeric comparisons more tightly than value inequality", () => {
      const ast = parse(`res = 1 #! 2 < 3`);
      const binding = ast.body[0] as BindingDeclaration;
      const inequality = binding.init as BinaryExpression;

      expect(inequality.operator).toBe("#!");
      expect((inequality.right as BinaryExpression).operator).toBe("<");
    });

    it("groups mixed equality and comparison operators", () => {
      const ast = parse(`res = 1 #= 2 < 3 #! 4 >= 5`);
      const inequality = (ast.body[0] as BindingDeclaration).init as BinaryExpression;

      // Equality operators associate left to right, while each comparison stays
      // grouped within its equality operand: (1 #= (2 < 3)) #! (4 >= 5).
      expect(inequality.operator).toBe("#!");
      const equality = inequality.left as BinaryExpression;
      expect(equality.operator).toBe("#=");
      expect((equality.right as BinaryExpression).operator).toBe("<");
      expect((inequality.right as BinaryExpression).operator).toBe(">=");
    });

    it("groups arithmetic, comparisons, equality, and logic by precedence", () => {
      const ast = parse(`res = 1 + 2 * 3 < 8 #= true and ready or fallback`);
      let node = (ast.body[0] as BindingDeclaration).init as BinaryExpression;

      expect(node.operator).toBe("or");
      node = node.left as BinaryExpression;
      expect(node.operator).toBe("and");
      node = node.left as BinaryExpression;
      expect(node.operator).toBe("#=");
      const comparison = node.left as BinaryExpression;
      expect(comparison.operator).toBe("<");
      const addition = comparison.left as BinaryExpression;
      expect(addition.operator).toBe("+");
      expect((addition.right as BinaryExpression).operator).toBe("*");
    });

    it("lets parentheses override comparison and equality precedence", () => {
      const ast = parse(`res = (1 < 2 #= true) and (3 + 4) * 5 < 40`);
      const logical = (ast.body[0] as BindingDeclaration).init as BinaryExpression;

      expect(logical.operator).toBe("and");
      expect((logical.left as BinaryExpression).operator).toBe("#=");
      const comparison = logical.right as BinaryExpression;
      expect(comparison.operator).toBe("<");
      expect((comparison.left as BinaryExpression).operator).toBe("*");
      expect(((comparison.left as BinaryExpression).left as BinaryExpression).operator).toBe("+");
    });

    it("parses unary expressions (not, -)", () => {
      const ast = parse(`
a = not active
b = -42
`);
      const u1 = (ast.body[0] as BindingDeclaration).init as UnaryExpression;
      expect(u1.kind).toBe("UnaryExpression");
      expect(u1.operator).toBe("not");

      const u2 = (ast.body[1] as BindingDeclaration).init as UnaryExpression;
      expect(u2.kind).toBe("UnaryExpression");
      expect(u2.operator).toBe("-");
    });

    it("parses calls, member accesses, and indices", () => {
      const ast = parse(`res = users.get(id)[0].profile.name`);
      const binding = ast.body[0] as BindingDeclaration;
      expect(binding.init.kind).toBe("MemberExpression");

      const member = binding.init as MemberExpression;
      expect(member.property.name).toBe("name");
    });

    it("parses array literals", () => {
      const ast = parse(`empty = []\nfilled = [1, 2, 3]`);
      const e = (ast.body[0] as BindingDeclaration).init as ArrayExpression;
      expect(e.kind).toBe("ArrayExpression");
      expect(e.elements.length).toBe(0);

      const f = (ast.body[1] as BindingDeclaration).init as ArrayExpression;
      expect(f.kind).toBe("ArrayExpression");
      expect(f.elements.length).toBe(3);
    });

    it("parses record literals: entries, shorthands, spreads, dot-paths", () => {
      const ast = parse(`
user = {
  id: "123"
  name
  ...existing
  address.city: "Paris"
}
`);
      const rec = (ast.body[0] as BindingDeclaration).init as RecordExpression;
      expect(rec.kind).toBe("RecordExpression");
      expect(rec.entries.length).toBe(4);

      expect(rec.entries[0].kind).toBe("FieldEntry");
      expect(rec.entries[1].kind).toBe("ShorthandEntry");
      expect(rec.entries[2].kind).toBe("SpreadEntry");
      expect(rec.entries[3].kind).toBe("DotPathEntry");
      if (rec.entries[3].kind === "DotPathEntry") {
        expect(rec.entries[3].path.map((p) => p.name)).toEqual(["address", "city"]);
      }
    });

    it("parses pipeline expressions and placeholder", () => {
      const ast = parse(`res = items |> process |> save(config, _)`);
      const pipe = (ast.body[0] as BindingDeclaration).init as PipelineExpression;
      expect(pipe.kind).toBe("PipelineExpression");

      const call = pipe.right as CallExpression;
      expect(call.kind).toBe("CallExpression");
      expect(call.args.some((a) => a.kind === "Placeholder")).toBe(true);
    });

    it("parses typed holes", () => {
      const ast = parse(`a = ???\nb = ??? "implement after v1"`);
      const h1 = (ast.body[0] as BindingDeclaration).init as TypedHole;
      expect(h1.kind).toBe("TypedHole");
      expect(h1.label).toBeUndefined();

      const h2 = (ast.body[1] as BindingDeclaration).init as TypedHole;
      expect(h2.kind).toBe("TypedHole");
      expect(h2.label).toBe("implement after v1");
    });

    it("parses lambda expressions with single and multiple parameters", () => {
      const ast = parse(`
f1 = () => 42
f2 = => 100
f3 = (x) => x + 1
f4 = (a: Number, b: Number): Number => a + b
`);
      const l1 = (ast.body[0] as BindingDeclaration).init as FunctionExpression;
      expect(l1.kind).toBe("FunctionExpression");
      expect(l1.params.length).toBe(0);

      const l2 = (ast.body[1] as BindingDeclaration).init as FunctionExpression;
      expect(l2.params.length).toBe(0);

      const l3 = (ast.body[2] as BindingDeclaration).init as FunctionExpression;
      expect(l3.params.length).toBe(1);
      expect(l3.params[0].name.name).toBe("x");

      const l4 = (ast.body[3] as BindingDeclaration).init as FunctionExpression;
      expect(l4.params.length).toBe(2);
      expect(l4.returnType?.kind).toBe("TypeReferenceNode");
    });

    it("parses multiline block function body with local statements", () => {
      const ast = parse(`
calculate = (x: Number) =>
  multiplier = 2
  temp = x * multiplier
  => temp + 1
`);
      const fn = (ast.body[0] as BindingDeclaration).init as FunctionExpression;
      expect(fn.body.kind).toBe("BlockStatement");
      const block = fn.body as BlockStatement;
      expect(block.statements.length).toBe(3);
      expect(block.statements[0].kind).toBe("BindingDeclaration");
      expect(block.statements[2].kind).toBe("ReturnStatement");
    });
  });

  describe("Mut Block Expressions", () => {
    it("parses mut blocks in pipelines", () => {
      const ast = parse(`
updated = user |> mut(draft) =>
  draft.tags.push("active")
  draft
`);
      const pipe = (ast.body[0] as BindingDeclaration).init as PipelineExpression;
      const mutBlock = pipe.right as MutBlockExpression;

      expect(mutBlock.kind).toBe("MutBlockExpression");
      expect(mutBlock.draftParam.name).toBe("draft");
      expect(mutBlock.body.kind).toBe("BlockStatement");

      const block = mutBlock.body as BlockStatement;
      expect(block.statements.length).toBe(1);
      expect(block.finalExpression.kind).toBe("Identifier");
    });
  });

  describe("Match Expressions", () => {
    it("parses scrutinee match with constructor patterns, variables, and wildcards", () => {
      const ast = parse(`
res = match shape
  | Circle(r) => r * 2
  | Rect(w, h) => w * h
  | Point => 0
  | other => other
  | _ => -1
`);
      const matchExpr = (ast.body[0] as BindingDeclaration).init as MatchExpression;
      expect(matchExpr.kind).toBe("MatchExpression");
      expect(matchExpr.scrutinee?.kind).toBe("Identifier");
      expect(matchExpr.arms.length).toBe(5);

      const a0 = matchExpr.arms[0];
      expect(a0.pattern.kind).toBe("ConstructorPattern");
      const cp0 = a0.pattern as ConstructorPattern;
      expect(cp0.constructorName.name).toBe("Circle");
      expect(cp0.args.length).toBe(1);

      const a1 = matchExpr.arms[1];
      const cp1 = a1.pattern as ConstructorPattern;
      expect(cp1.constructorName.name).toBe("Rect");
      expect(cp1.args.length).toBe(2);

      const a2 = matchExpr.arms[2];
      const cp2 = a2.pattern as ConstructorPattern;
      expect(cp2.constructorName.name).toBe("Point");
      expect(cp2.args.length).toBe(0);

      const a3 = matchExpr.arms[3];
      expect(a3.pattern.kind).toBe("VariablePattern");
      expect((a3.pattern as VariablePattern).name.name).toBe("other");

      const a4 = matchExpr.arms[4];
      expect(a4.pattern.kind).toBe("WildcardPattern");
    });

    it("parses match arm guards (when)", () => {
      const ast = parse(`
res = match shape
  | Circle(r) when r |> Number.isGreaterThan(0) => r
  | _ => 0
`);
      const matchExpr = (ast.body[0] as BindingDeclaration).init as MatchExpression;
      expect(matchExpr.arms[0].guard).toBeDefined();
      expect(matchExpr.arms[0].guard?.kind).toBe("PipelineExpression");
    });

    it("parses literal patterns (numbers, booleans) in match arms", () => {
      const ast = parse(`
res = match flag
  | true => 1
  | false => 0
`);
      const matchExpr = (ast.body[0] as BindingDeclaration).init as MatchExpression;
      expect(matchExpr.arms.length).toBe(2);
      expect(matchExpr.arms[0].pattern.kind).toBe("LiteralPattern");
      expect(matchExpr.arms[1].pattern.kind).toBe("LiteralPattern");
    });

    it("parses OrPattern in match arm", () => {
      const ast = parse(`
res = match code
  | 200 | 201 | 204 => "ok"
  | _ => "err"
`);
      const matchExpr = (ast.body[0] as BindingDeclaration).init as MatchExpression;
      const orPat = matchExpr.arms[0].pattern as OrPattern;
      expect(orPat.kind).toBe("OrPattern");
      expect(orPat.patterns.length).toBe(3);
    });

    it("parses subjectless boolean match expressions", () => {
      const ast = parse(`
grade = match
  | score |> Number.isGreaterThan(90) => "A"
  | score |> Number.isGreaterThan(80) => "B"
  | _ => "C"
`);
      const matchExpr = (ast.body[0] as BindingDeclaration).init as MatchExpression;
      expect(matchExpr.scrutinee).toBeUndefined();
      expect(matchExpr.arms.length).toBe(3);

      expect(matchExpr.arms[0].pattern.kind).toBe("LiteralPattern");
      expect(matchExpr.arms[2].pattern.kind).toBe("WildcardPattern");
    });
  });

  describe("Effect Blocks", () => {
    it("requires explicit returns in effect blocks", () => {
      expect(() => parse("result = effect {\n  => 1\n}")).not.toThrow();
      expect(() => parse("result = effect {\n  1\n}")).toThrow(/explicit '=> returnValue'/);
    });
    it("parses a brace-delimited effect expression", () => {
      const ast = parse(`result = effect {\n  user <- fetchUser()\n  => user |> summarize\n}`);
      const eff = (ast.body[0] as BindingDeclaration).init as EffectBlockExpression;
      expect(eff.body[0].kind).toBe("EffectBindStatement");
      expect(eff.finalExpression.kind).toBe("PipelineExpression");
    });

    it("parses effect block with binds, discards, local bindings, and final return", () => {
      const ast = parse(`
getUser = (id: String) => effect
  user <- UserRepo.find(id)
  _ <- Console.log(user)
  prefix = "User: "
  => user
`);
      const fn = (ast.body[0] as BindingDeclaration).init as FunctionExpression;
      const eff = fn.body as EffectBlockExpression;

      expect(eff.kind).toBe("EffectBlockExpression");
      expect(eff.body.length).toBe(3);

      expect(eff.body[0].kind).toBe("EffectBindStatement");
      const bind = eff.body[0] as EffectBindStatement;
      expect(bind.id.name).toBe("user");

      expect(eff.body[1].kind).toBe("EffectDiscardStatement");
      const discard = eff.body[1] as EffectDiscardStatement;
      expect(discard.effect.kind).toBe("CallExpression");

      expect(eff.body[2].kind).toBe("BindingDeclaration");
      const local = eff.body[2] as BindingDeclaration;
      expect(local.id.name).toBe("prefix");

      expect(eff.finalExpression.kind).toBe("Identifier");
    });

    it("throws ParseError when non-final bare expression is placed in effect block", () => {
      const code = `
run = () =>
  effect
    Console.log("not bound with <-")
    "done"
`;
      expect(() => parse(code)).toThrow(ParseError);
      expect(() => parse(code)).toThrow(/Non-final bare expression in effect block is not executed/);
    });

    it("throws ParseError when effect block does not end with an expression", () => {
      const code = `
run = () =>
  effect
    user <- UserRepo.find("1")
`;
      expect(() => parse(code)).toThrow(ParseError);
      expect(() => parse(code)).toThrow(/Effect block must end with an explicit/);
    });
  });

  describe("Explicit block returns", () => {
    it("requires an explicit => returnValue at the end of function blocks", () => {
      expect(() => parse(`
increment = (value) =>
  next = value + 1
  next
`)).toThrow(/Function block must end with an explicit '=> returnValue'/);

      const ast = parse(`
increment = (value) =>
  next = value + 1
  => next
`);
      const fn = (ast.body[0] as BindingDeclaration).init as FunctionExpression;
      expect((fn.body as BlockStatement).statements.at(-1)?.kind).toBe("ReturnStatement");
    });

    it("keeps expression-bodied lambdas concise", () => {
      const ast = parse(`increment = (value) => value + 1`);
      const fn = (ast.body[0] as BindingDeclaration).init as FunctionExpression;
      expect(fn.body.kind).toBe("BinaryExpression");
    });
  });

  describe("Parser Error Handling", () => {
    it("throws ParseError on empty parens not followed by arrow", () => {
      expect(() => parse(`x = () + 1`)).toThrow(ParseError);
      expect(() => parse(`x = () + 1`)).toThrow(/Empty parentheses '\(\)' must be followed by '=>'/);
    });

    it("throws ParseError on missing required tokens", () => {
      expect(() => parse(`schema User`)).toThrow(ParseError);
      expect(() => parse(`import { foo }`)).toThrow(ParseError);
      expect(() => parse(`service MyService`)).toThrow(ParseError);
      expect(() => parse(`export schema MySchema = { id }`)).toThrow(ParseError);
      expect(() => parse(`export ts 123`)).toThrow("Expected '{ ... }' after 'ts'");
      expect(() => parse(`ts 123`)).toThrow("Expected '{ ... }' after 'ts'");
    });

    it("throws actionable ParseErrors with source locations for imported TypeScript schemas", () => {
      // Missing 'ts' after 'from'
      expect(() => parse(`schema User = from`)).toThrowError(
        /Expected 'ts' after 'from'/
      );
      expect(() => parse(`schema User = from other<Type>`)).toThrowError(
        /Expected 'ts' after 'from'/
      );

      // Missing '<' after 'ts'
      expect(() => parse(`schema User = from ts`)).toThrowError(
        /Expected '<' after 'ts'/
      );
      expect(() => parse(`schema User = from ts(Type)`)).toThrowError(
        /Expected '<' after 'ts'/
      );

      // Empty type arguments in ts<>
      expect(() => parse(`schema User = from ts<>`)).toThrowError(
        /Expected type argument inside 'ts<...>'/
      );

      // Missing closing '>'
      expect(() => parse(`schema User = from ts<Type`)).toThrowError(
        /Expected '>' after type argument/
      );

      // Invalid lowercase type name inside ts<...>
      expect(() => parse(`schema User = from ts<lowercase>`)).toThrowError(
        /Type names must begin with an uppercase letter/
      );

      // Accurate source location verification
      try {
        parse(`schema User = from ts<>`);
        expect.unreachable("should have thrown ParseError");
      } catch (err: any) {
        expect(err).toBeInstanceOf(ParseError);
        expect(err.span.start.offset).toBe(22); // offset of '>'
      }
    });
  });
});
