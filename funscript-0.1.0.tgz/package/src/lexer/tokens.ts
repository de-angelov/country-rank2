import { Position, Span } from "../ast/types.js";

export enum TokenType {
  // Layout
  INDENT = "INDENT",
  DEDENT = "DEDENT",
  NEWLINE = "NEWLINE",
  EOF = "EOF",

  // Literals
  NUMBER = "NUMBER",
  STRING = "STRING",
  TS_CODE = "TS_CODE",
  AS_CODE = "AS_CODE",
  STRING_PART = "STRING_PART",
  TEMPLATE_STRING = "TEMPLATE_STRING",
  TEMPLATE_PART = "TEMPLATE_PART",
  INTERPOLATION_START = "INTERPOLATION_START",
  INTERPOLATION_END = "INTERPOLATION_END",

  // Identifiers
  IDENTIFIER = "IDENTIFIER",
  UPPER_IDENTIFIER = "UPPER_IDENTIFIER",

  // Keywords
  AND = "and",
  AS = "as",
  DEFAULT = "default",
  EFFECT = "effect",
  ERROR = "error",
  EXPORT = "export",
  FALSE = "false",
  FROM = "from",
  IMPORT = "import",
  JS = "js",
  MATCH = "match",
  MUT = "mut",
  NOT = "not",
  OR = "or",
  SCHEMA = "schema",
  SERVICE = "service",
  TRUE = "true",
  TS = "ts",
  WHEN = "when",

  // Operators & Delimiters
  ARROW = "=>",
  LARROW = "<-",
  PIPE = "|>",
  BAR = "|",
  AMP = "&",
  UNDERSCORE = "_",
  TYPED_HOLE = "???",
  QUESTION = "?",
  EQ = "=",
  VALUE_EQ = "#=",
  VALUE_NEQ = "#!",
  REF_EQ = "@=",
  REF_NEQ = "@!",
  PLUS = "+",
  MINUS = "-",
  STAR = "*",
  SLASH = "/",
  PERCENT = "%",
  STARSTAR = "**",
  COLON = ":",
  COMMA = ",",
  DOT = ".",
  DOTDOTDOT = "...",
  LPAREN = "(",
  RPAREN = ")",
  LBRACE = "{",
  RBRACE = "}",
  LBRACKET = "[",
  RBRACKET = "]",
  LT = "<",
  GT = ">",
  LTE = "<=",
  GTE = ">=",

  // JSX Tokens
  JSX_TAG_OPEN = "JSX_TAG_OPEN",
  JsxTagOpen = "JSX_TAG_OPEN",
  JSX_TAG_CLOSE = "JSX_TAG_CLOSE",
  JsxTagClose = "JSX_TAG_CLOSE",
  JSX_SLASH_CLOSE = "JSX_SLASH_CLOSE",
  JsxSlashClose = "JSX_SLASH_CLOSE",
  JSX_CLOSING_TAG_OPEN = "JSX_CLOSING_TAG_OPEN",
  JsxClosingTagOpen = "JSX_CLOSING_TAG_OPEN",
  JSX_ATTRIBUTE_NAME = "JSX_ATTRIBUTE_NAME",
  JsxAttributeName = "JSX_ATTRIBUTE_NAME",
  JSX_TEXT = "JSX_TEXT",
  JsxText = "JSX_TEXT",
  JSX_TAG_NAME = "JSX_TAG_NAME",
  JsxTagName = "JSX_TAG_NAME",
}

export interface Token {
  type: TokenType;
  value: string;
  span: Span;
  /** Start of the trimmed payload inside a verbatim block. */
  contentStart?: Position;
}

export const KEYWORDS: Record<string, TokenType> = {
  and: TokenType.AND,
  default: TokenType.DEFAULT,
  effect: TokenType.EFFECT,
  error: TokenType.ERROR,
  export: TokenType.EXPORT,
  false: TokenType.FALSE,
  from: TokenType.FROM,
  import: TokenType.IMPORT,
  js: TokenType.JS,
  match: TokenType.MATCH,
  mut: TokenType.MUT,
  not: TokenType.NOT,
  or: TokenType.OR,
  schema: TokenType.SCHEMA,
  service: TokenType.SERVICE,
  true: TokenType.TRUE,
  ts: TokenType.TS,
  when: TokenType.WHEN,
};

export const BANNED_KEYWORDS: Record<string, string> = {
  extern: "FunScript has retired 'extern service'. Declare interfaces using 'service Name' and implement them in a Layer using 'js' for foreign calls.",
  let: "FunScript has no 'let'; use 'name = value' for immutable bindings, or 'mut name = value' for local mutable drafts.",
  var: "FunScript has no 'var'; use 'name = value' for immutable bindings, or 'mut name = value' for local mutable drafts.",
  const: "FunScript bindings are const by default; write 'name = value'.",
  function: "FunScript functions use the arrow syntax: '(args) => body'.",
  class: "FunScript has no classes; use 'schema' for data, 'error' for errors, and 'service' for services.",
  return: "FunScript uses '=> value' for explicit returns in function and effect blocks; replace 'return x' with '=> x'. See docs/syntax.md#311-explicit-returns-and-conditional-execution.",
  throw: "FunScript has no 'throw'; recoverable failures use Effect typed errors, and defects use 'Effect.die' or '|> orDie'.",
  try: "FunScript has no 'try/catch'; use typed errors in the E channel or 'Effect.tryPromise'.",
  catch: "FunScript has no 'try/catch'; handle errors with 'Effect.catchTag' or 'match'.",
  finally: "Use 'Effect.ensuring' or 'Effect.acquireRelease' for deterministic finalizers.",
  async: "FunScript has no 'async/await'; use 'effect' blocks with '<-'.",
  await: "FunScript has no 'await'; execute effects inside 'effect' blocks using '<-'.",
  null: "FunScript has no 'null'; use Option.none() or Option<T> for optional values.",
  undefined: "FunScript has no 'undefined'; use Option<T> or explicit types.",
  if: "FunScript has no 'if'; use 'match' for both pattern matching and boolean branching.",
  else: "FunScript has no 'else'; use '| _ =>' in 'match'.",
  switch: "FunScript has no 'switch'; use 'match'.",
  for: "FunScript has no 'for' loops; use Array pipelines (map, filter) or Effect.forEach.",
  while: "FunScript has no 'while' loops; use Effect.repeat, Schedule, or recursion.",
  type: "FunScript replaces 'type' with 'schema' (export schema Name = ...).",
  data: "FunScript uses 'schema' for all data modeling and tagged unions.",
  interface: "FunScript has no 'interface'; use 'schema' or 'service'.",
};

export const BANNED_SYMBOLS: Record<string, string> = {
  "&&": "FunScript logical AND is 'and'.",
  "||": "FunScript logical OR is 'or'.",
  "!": "FunScript logical NOT is 'not'.",
  "==": "FunScript equality uses '#=' for value equality or '@=' for reference identity.",
  "!=": "FunScript inequality uses '#!' for value inequality or '@!' for reference identity.",
  "===": "FunScript reference identity uses '@='.",
  "!==": "FunScript reference inequality uses '@!'.",
  "??": "FunScript has no nullish coalescing; model absence with Option instead.",
};

// JSX token constants for direct imports
export const JsxTagOpen = TokenType.JsxTagOpen;
export const JsxTagClose = TokenType.JsxTagClose;
export const JsxSlashClose = TokenType.JsxSlashClose;
export const JsxClosingTagOpen = TokenType.JsxClosingTagOpen;
export const JsxAttributeName = TokenType.JsxAttributeName;
export const JsxText = TokenType.JsxText;
export const JsxTagName = TokenType.JsxTagName;

