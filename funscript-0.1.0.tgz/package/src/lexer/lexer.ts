import { Position, Span } from "../ast/types.js";
import { FunScriptError } from "../errors.js";
import {
  Token,
  TokenType,
  KEYWORDS,
  BANNED_KEYWORDS,
  BANNED_SYMBOLS,
} from "./tokens.js";

export class LexerError extends FunScriptError {
  constructor(message: string, span: Span) {
    super(message, span);
    this.name = "LexerError";
  }
}

export interface LexerOptions {
  jsx?: boolean;
}

export class Lexer {
  private offset = 0;
  private line = 1;
  private column = 1;
  private indentStack: number[] = [0];
  private parenLevel = 0;
  private bracketLevel = 0;
  private braceStack: ("record" | "interpolation" | "jsx_expr")[] = [];
  private jsxStack: Array<{ kind: "tag" | "closing_tag" | "children" | "expr"; hasTagName?: boolean }> = [];
  private isFunx: boolean;
  private tokens: Token[] = [];
  private atLineStart = true;

  constructor(
    private source: string,
    private filename: string = "<anonymous>",
    options?: LexerOptions | boolean,
  ) {
    if (typeof options === "boolean") {
      this.isFunx = options;
    } else if (options && typeof options.jsx === "boolean") {
      this.isFunx = options.jsx;
    } else {
      this.isFunx = this.filename.endsWith(".funx");
    }
  }

  public tokenize(): Token[] {
    while (!this.isAtEnd()) {
      if (this.atLineStart) {
        this.handleIndentation();
      }

      if (this.isAtEnd()) break;

      if (this.isFunx && this.jsxStack.length > 0 && !this.braceStack.includes("interpolation")) {
        const top = this.jsxStack[this.jsxStack.length - 1];
        if (top.kind === "children") {
          this.readJsxChildren();
          continue;
        } else if (top.kind === "tag" || top.kind === "closing_tag") {
          this.readJsxTag(top);
          continue;
        }
      }

      const char = this.peek();

      // Whitespace (inline)
      if (char === " " || char === "\t") {
        if (char === "\t") {
          throw new LexerError("Tabs are not allowed for indentation or spacing; use 2 spaces", this.currentSpan(1));
        }
        this.advance();
        continue;
      }

      // Newlines
      if (char === "\r" || char === "\n") {
        this.advanceNewline();
        continue;
      }

      // Banned multi-character operators check
      if (this.matchAhead("&&")) {
        throw new LexerError(BANNED_SYMBOLS["&&"], this.currentSpan(2));
      }
      if (this.matchAhead("||")) {
        throw new LexerError(BANNED_SYMBOLS["||"], this.currentSpan(2));
      }

      // Equality operators must precede comments: '#' starts a comment unless
      // it is immediately followed by '=' or '!'.
      if (this.matchAhead("#=")) {
        this.emitToken(TokenType.VALUE_EQ, "#=", 2);
        continue;
      }
      if (this.matchAhead("#!")) {
        this.emitToken(TokenType.VALUE_NEQ, "#!", 2);
        continue;
      }
      if (this.matchAhead("@=")) {
        this.emitToken(TokenType.REF_EQ, "@=", 2);
        continue;
      }
      if (this.matchAhead("@!")) {
        this.emitToken(TokenType.REF_NEQ, "@!", 2);
        continue;
      }
      if (this.matchAhead("===") || this.matchAhead("!==")) {
        const op = this.source.slice(this.offset, this.offset + 3);
        throw new LexerError(BANNED_SYMBOLS[op], this.currentSpan(3));
      }
      if (this.matchAhead("==") || this.matchAhead("!=")) {
        const op = this.source.slice(this.offset, this.offset + 2);
        throw new LexerError(BANNED_SYMBOLS[op], this.currentSpan(2));
      }

      // TypeScript-style line comments
      if (this.matchAhead("//")) {
        this.skipComment();
        continue;
      }

      // Multi-character operators
      if (this.matchAhead("???")) {
        this.emitToken(TokenType.TYPED_HOLE, "???", 3);
        continue;
      }
      if (this.matchAhead("...")) {
        this.emitToken(TokenType.DOTDOTDOT, "...", 3);
        continue;
      }
      if (this.matchAhead("=>")) {
        this.emitToken(TokenType.ARROW, "=>", 2);
        continue;
      }
      if (this.matchAhead("<-")) {
        this.emitToken(TokenType.LARROW, "<-", 2);
        continue;
      }
      if (this.matchAhead("|>")) {
        this.emitToken(TokenType.PIPE, "|>", 2);
        continue;
      }
      if (this.matchAhead("**")) {
        this.emitToken(TokenType.STARSTAR, "**", 2);
        continue;
      }
      if (this.matchAhead("??")) {
        throw new LexerError(BANNED_SYMBOLS["??"], this.currentSpan(2));
      }

      // Strings
      if (char === '"') {
        this.readString();
        continue;
      }

      // Numbers
      if (this.isDigit(char)) {
        this.readNumber();
        continue;
      }

      // Identifiers / Keywords
      if (this.isAlpha(char) || char === "_") {
        this.readIdentifierOrKeyword();
        continue;
      }

      // Single-character symbols
      switch (char) {
        case "=":
          this.emitToken(TokenType.EQ, "=", 1);
          break;
        case "|":
          this.emitToken(TokenType.BAR, "|", 1);
          break;
        case "+":
          this.emitToken(TokenType.PLUS, "+", 1);
          break;
        case "-":
          this.emitToken(TokenType.MINUS, "-", 1);
          break;
        case "*":
          this.emitToken(TokenType.STAR, "*", 1);
          break;
        case "/":
          this.emitToken(TokenType.SLASH, "/", 1);
          break;
        case "%":
          this.emitToken(TokenType.PERCENT, "%", 1);
          break;
        case "?":
          this.emitToken(TokenType.QUESTION, "?", 1);
          break;
        case ":":
          this.emitToken(TokenType.COLON, ":", 1);
          break;
        case ",":
          this.emitToken(TokenType.COMMA, ",", 1);
          break;
        case ".":
          this.emitToken(TokenType.DOT, ".", 1);
          break;
        case "(":
          this.parenLevel++;
          this.emitToken(TokenType.LPAREN, "(", 1);
          break;
        case ")":
          if (this.parenLevel > 0) this.parenLevel--;
          this.emitToken(TokenType.RPAREN, ")", 1);
          break;
        case "[":
          this.bracketLevel++;
          this.emitToken(TokenType.LBRACKET, "[", 1);
          break;
        case "]":
          if (this.bracketLevel > 0) this.bracketLevel--;
          this.emitToken(TokenType.RBRACKET, "]", 1);
          break;
        case "{":
          this.braceStack.push("record");
          this.emitToken(TokenType.LBRACE, "{", 1);
          break;
        case "}":
          if (this.braceStack.length > 0 && this.braceStack[this.braceStack.length - 1] === "interpolation") {
            this.braceStack.pop();
            this.emitToken(TokenType.INTERPOLATION_END, "}", 1);
            this.continueStringAfterInterpolation();
          } else if (this.braceStack.length > 0 && this.braceStack[this.braceStack.length - 1] === "jsx_expr") {
            this.braceStack.pop();
            if (this.jsxStack.length > 0 && this.jsxStack[this.jsxStack.length - 1].kind === "expr") {
              this.jsxStack.pop();
            }
            this.emitToken(TokenType.RBRACE, "}", 1);
          } else {
            if (this.braceStack.length > 0) this.braceStack.pop();
            this.emitToken(TokenType.RBRACE, "}", 1);
          }
          break;
        case "<":
          if (this.isFunx && this.matchAhead("</")) {
            this.emitToken(TokenType.JSX_CLOSING_TAG_OPEN, "</", 2);
            this.jsxStack.push({ kind: "closing_tag", hasTagName: false });
          } else if (this.isJsxTagStart()) {
            this.emitToken(TokenType.JSX_TAG_OPEN, "<", 1);
            this.jsxStack.push({ kind: "tag", hasTagName: false });
          } else {
            const isEqual = this.matchAhead("<=");
            this.emitToken(isEqual ? TokenType.LTE : TokenType.LT, isEqual ? "<=" : "<", isEqual ? 2 : 1);
          }
          break;
        case ">":
          const isEqual = this.matchAhead(">=");
          this.emitToken(isEqual ? TokenType.GTE : TokenType.GT, isEqual ? ">=" : ">", isEqual ? 2 : 1);
          break;
        case "!":
          throw new LexerError(BANNED_SYMBOLS["!"], this.currentSpan(1));
        default:
          throw new LexerError(`Unexpected character '${char}'`, this.currentSpan(1));
      }
    }

    // Flush remaining indentation
    while (this.indentStack.length > 1) {
      this.indentStack.pop();
      this.tokens.push({
        type: TokenType.DEDENT,
        value: "",
        span: this.currentSpan(0),
      });
    }

    // Final EOF token
    this.tokens.push({
      type: TokenType.EOF,
      value: "",
      span: this.currentSpan(0),
    });

    return this.tokens;
  }

  private handleIndentation(): void {
    if (this.bracketLevel > 0 || this.isInJsxChildrenOrTag()) {
      this.atLineStart = false;
      return;
    }

    let spaces = 0;
    const startPos = this.currentPosition();

    while (!this.isAtEnd()) {
      const c = this.peek();
      if (c === " ") {
        spaces++;
        this.advance();
      } else if (c === "\t") {
        throw new LexerError("Tabs are not allowed for indentation; use 2 spaces", this.currentSpan(1));
      } else {
        break;
      }
    }

    // If entire line is blank or a comment, ignore indentation.
    if (this.peek() === "\r" || this.peek() === "\n" || this.matchAhead("//") || this.isAtEnd()) {
      this.atLineStart = false;
      return;
    }

    this.atLineStart = false;

    const currentIndent = this.indentStack[this.indentStack.length - 1];

    if (spaces > currentIndent) {
      this.indentStack.push(spaces);
      this.tokens.push({
        type: TokenType.INDENT,
        value: " ".repeat(spaces),
        span: { start: startPos, end: this.currentPosition() },
      });
    } else if (spaces < currentIndent) {
      while (this.indentStack.length > 1 && this.indentStack[this.indentStack.length - 1] > spaces) {
        this.indentStack.pop();
        this.tokens.push({
          type: TokenType.DEDENT,
          value: "",
          span: { start: startPos, end: this.currentPosition() },
        });
      }
      if (this.indentStack[this.indentStack.length - 1] !== spaces) {
        throw new LexerError(
          `Inconsistent indentation: unindent does not match any outer indentation level (expected ${this.indentStack.join(", ")}, got ${spaces})`,
          { start: startPos, end: this.currentPosition() },
        );
      }
    }
  }

  private advanceNewline(): void {
    const startPos = this.currentPosition();
    if (this.peek() === "\r") this.advance();
    if (this.peek() === "\n") this.advance();

    this.line++;
    this.column = 1;
    this.atLineStart = true;

    const lastToken = this.tokens[this.tokens.length - 1];
    if (lastToken && lastToken.type !== TokenType.NEWLINE && lastToken.type !== TokenType.INDENT) {
      this.tokens.push({
        type: TokenType.NEWLINE,
        value: "\n",
        span: { start: startPos, end: this.currentPosition() },
      });
    }
  }

  private readString(): void {
    const startPos = this.currentPosition();
    this.advance(); // consume opening '"'

    let buffer = "";

    while (!this.isAtEnd() && this.peek() !== '"') {
      const c = this.peek();

      if (c === "\n" || c === "\r") {
        throw new LexerError("Unterminated string literal (newline in string)", {
          start: startPos,
          end: this.currentPosition(),
        });
      }

      if (c === "\\") {
        this.advance();
        if (this.isAtEnd()) break;
        const esc = this.advance();
        if (esc === "n") buffer += "\n";
        else if (esc === "t") buffer += "\t";
        else if (esc === "r") buffer += "\r";
        else if (esc === '"') buffer += '"';
        else if (esc === "\\") buffer += "\\";
        else if (esc === "{") buffer += "{";
        else buffer += "\\" + esc;
        continue;
      }

      if (c === "{") {
        // Start of interpolation
        const inJsxTag = this.isFunx && this.jsxStack.length > 0 && this.jsxStack[this.jsxStack.length - 1].kind === "tag";
        if (inJsxTag && buffer.endsWith("$")) {
          buffer = buffer.slice(0, -1);
        }
        if (buffer.length > 0) {
          this.tokens.push({
            type: TokenType.STRING_PART,
            value: buffer,
            span: { start: startPos, end: this.currentPosition() },
          });
          buffer = "";
        }
        this.advance(); // consume '{'
        this.braceStack.push("interpolation");
        this.tokens.push({
          type: TokenType.INTERPOLATION_START,
          value: "{",
          span: this.currentSpan(1),
        });
        return; // transition to normal tokenizing for expression inside
      }

      buffer += this.advance();
    }

    if (this.isAtEnd()) {
      throw new LexerError("Unterminated string literal", {
        start: startPos,
        end: this.currentPosition(),
      });
    }

    this.advance(); // consume closing '"'

    this.tokens.push({
      type: TokenType.STRING,
      value: buffer,
      span: { start: startPos, end: this.currentPosition() },
    });
  }

  /**
   * Reads the verbatim TypeScript payload that follows the 'ts' keyword.
   *
   * The sole form is a balanced brace block. Its contents are verbatim TypeScript:
   *   ts { Record<string, { a: number }> }
   *   ts { interface Foo { a: number } }
   */
  private readTsCode(): void {
    while (this.peek() === " ") this.advance();
    const startPos = this.currentPosition();

    if (this.peek() !== "{") {
      throw new LexerError("Expected '{ ... }' after 'ts'", this.currentSpan(1));
    }

    this.advance(); // opening '{'
    let depth = 1;
    let code = "";
    let quote: '"' | "'" | "`" | null = null;
    let lineComment = false;
    let blockComment = false;

    while (!this.isAtEnd() && depth > 0) {
      const c = this.advance();
      const next = this.peek();
      if (c === "\n") {
        this.line++;
        this.column = 1;
        lineComment = false;
      }
      if (lineComment) { code += c; continue; }
      if (blockComment) {
        code += c;
        if (c === "*" && next === "/") { code += this.advance(); blockComment = false; }
        continue;
      }
      if (quote) {
        code += c;
        if (c === "\\") { code += this.advance(); continue; }
        if (c === quote) quote = null;
        continue;
      }
      if (c === "/" && next === "/") { code += c + this.advance(); lineComment = true; continue; }
      if (c === "/" && next === "*") { code += c + this.advance(); blockComment = true; continue; }
      if (c === '"' || c === "'" || c === "`") { quote = c; code += c; continue; }
      if (c === "{") { depth++; code += c; continue; }
      if (c === "}") {
        depth--;
        if (depth > 0) code += c;
        continue;
      }
      code += c;
    }

    if (depth !== 0) throw new LexerError("Unterminated 'ts { ... }' block", { start: startPos, end: this.currentPosition() });
    if (code.trim() === "") throw new LexerError("Empty 'ts { ... }' block", { start: startPos, end: this.currentPosition() });
    this.tokens.push({ type: TokenType.TS_CODE, value: code.trim(), span: { start: startPos, end: this.currentPosition() } });
  }

  private continueStringAfterInterpolation(): void {
    const startPos = this.currentPosition();
    let buffer = "";

    while (!this.isAtEnd() && this.peek() !== '"') {
      const c = this.peek();
      if (c === "{" && this.peekPrev() !== "\\") {
        const inJsxTag = this.isFunx && this.jsxStack.length > 0 && this.jsxStack[this.jsxStack.length - 1].kind === "tag";
        if (inJsxTag && buffer.endsWith("$")) {
          buffer = buffer.slice(0, -1);
        }
        if (buffer.length > 0) {
          this.tokens.push({
            type: TokenType.STRING_PART,
            value: buffer,
            span: { start: startPos, end: this.currentPosition() },
          });
          buffer = "";
        }
        this.advance();
        this.braceStack.push("interpolation");
        this.tokens.push({
          type: TokenType.INTERPOLATION_START,
          value: "{",
          span: this.currentSpan(1),
        });
        return;
      }
      buffer += this.advance();
    }

    if (!this.isAtEnd() && this.peek() === '"') {
      this.advance(); // consume closing '"'
    }

    if (buffer.length > 0) {
      this.tokens.push({
        type: TokenType.STRING_PART,
        value: buffer,
        span: { start: startPos, end: this.currentPosition() },
      });
    }
  }

  private readNumber(): void {
    const startPos = this.currentPosition();
    let raw = "";

    raw += this.readDigitsWithSeparators();

    if (!this.isAtEnd() && this.peek() === "." && this.isDigit(this.peekAhead(1))) {
      raw += this.advance(); // consume '.'
      raw += this.readDigitsWithSeparators();
    } else if (!this.isAtEnd() && this.peek() === "." && this.peekAhead(1) === "_") {
      throw new LexerError("Numeric separator must appear between two digits", this.currentSpan(2));
    }

    this.tokens.push({
      type: TokenType.NUMBER,
      value: raw,
      span: { start: startPos, end: this.currentPosition() },
    });
  }

  /** Reads decimal digits, allowing `_` only between two digits. */
  private readDigitsWithSeparators(): string {
    let raw = "";
    while (!this.isAtEnd() && this.isDigit(this.peek())) raw += this.advance();
    while (!this.isAtEnd() && this.peek() === "_") {
      if (!this.isDigit(this.peekAhead(1))) {
        throw new LexerError("Numeric separator must appear between two digits", this.currentSpan(1));
      }
      raw += this.advance();
      while (!this.isAtEnd() && this.isDigit(this.peek())) raw += this.advance();
    }
    return raw;
  }

  private readIdentifierOrKeyword(): void {
    const startPos = this.currentPosition();
    let raw = "";

    while (!this.isAtEnd() && (this.isAlphaNumeric(this.peek()) || this.peek() === "_")) {
      raw += this.advance();
    }

    const span = { start: startPos, end: this.currentPosition() };

    // Check banned keywords
    if (BANNED_KEYWORDS[raw]) {
      const lastToken = this.tokens[this.tokens.length - 1];
      if (lastToken && lastToken.type === TokenType.DOT) {
        this.tokens.push({
          type: TokenType.IDENTIFIER,
          value: raw,
          span,
        });
        return;
      }
      if (raw === "type" || raw === "data") {
        if (
          (lastToken && lastToken.type === TokenType.IMPORT) ||
          this.braceStack.includes("record")
        ) {
          this.tokens.push({
            type: TokenType.IDENTIFIER,
            value: raw,
            span,
          });
          return;
        }
        if (lastToken && (lastToken.type === TokenType.LBRACE || lastToken.type === TokenType.COMMA)) {
          for (let j = this.tokens.length - 1; j >= 0; j--) {
            if (this.tokens[j].type === TokenType.NEWLINE) break;
            if (this.tokens[j].type === TokenType.IMPORT) {
              this.tokens.push({
                type: TokenType.IDENTIFIER,
                value: raw,
                span,
              });
              return;
            }
          }
        }
      }
      throw new LexerError(BANNED_KEYWORDS[raw], span);
    }

    // Check active keywords
    if (KEYWORDS[raw]) {
      this.tokens.push({
        type: KEYWORDS[raw],
        value: raw,
        span,
      });
      if (raw === "ts") {
        let prevIdx = this.tokens.length - 2;
        while (prevIdx >= 0 && (this.tokens[prevIdx].type === TokenType.NEWLINE || this.tokens[prevIdx].type === TokenType.INDENT)) {
          prevIdx--;
        }
        const prev = prevIdx >= 0 ? this.tokens[prevIdx] : undefined;
        if (prev?.type === TokenType.FROM) {
          return;
        }

        let p = this.offset;
        while (p < this.source.length && (this.source[p] === " " || this.source[p] === "\t")) {
          p++;
        }
        if (
          this.source.slice(p, p + 6) === "schema" &&
          (p + 6 >= this.source.length || !/[a-zA-Z0-9_]/.test(this.source[p + 6]))
        ) {
          return;
        }
        this.readTsCode();
        return;
      }
      return;
    }

    // Placeholder '_'
    if (raw === "_") {
      this.tokens.push({
        type: TokenType.UNDERSCORE,
        value: "_",
        span,
      });
      return;
    }

    // UpperCamel vs lowerCamel
    if (raw[0] >= "A" && raw[0] <= "Z") {
      this.tokens.push({
        type: TokenType.UPPER_IDENTIFIER,
        value: raw,
        span,
      });
    } else {
      this.tokens.push({
        type: TokenType.IDENTIFIER,
        value: raw,
        span,
      });
    }
  }

  private skipComment(): void {
    while (!this.isAtEnd() && this.peek() !== "\n" && this.peek() !== "\r") {
      this.advance();
    }
  }

  private isAtEnd(): boolean {
    return this.offset >= this.source.length;
  }

  private peek(): string {
    return this.source[this.offset] || "\0";
  }

  private peekPrev(): string {
    return this.source[this.offset - 1] || "\0";
  }

  private peekAhead(n: number): string {
    return this.source[this.offset + n] || "\0";
  }

  private matchAhead(str: string): boolean {
    if (this.source.slice(this.offset, this.offset + str.length) === str) {
      return true;
    }
    return false;
  }

  private advance(): string {
    const c = this.source[this.offset++];
    this.column++;
    return c;
  }

  private emitToken(type: TokenType, value: string, length: number): void {
    const start = this.currentPosition();
    for (let i = 0; i < length; i++) {
      this.advance();
    }
    this.tokens.push({
      type,
      value,
      span: { start, end: this.currentPosition() },
    });
  }

  private isDigit(c: string): boolean {
    return c >= "0" && c <= "9";
  }

  private isAlpha(c: string): boolean {
    return (c >= "a" && c <= "z") || (c >= "A" && c <= "Z");
  }

  private isAlphaNumeric(c: string): boolean {
    return this.isAlpha(c) || this.isDigit(c);
  }

  private currentPosition(): Position {
    return {
      line: this.line,
      column: this.column,
      offset: this.offset,
    };
  }

  private currentSpan(length: number): Span {
    return {
      start: this.currentPosition(),
      end: {
        line: this.line,
        column: this.column + length,
        offset: this.offset + length,
      },
    };
  }

  private isInJsxChildrenOrTag(): boolean {
    if (this.jsxStack.length === 0) return false;
    const top = this.jsxStack[this.jsxStack.length - 1];
    return top.kind === "tag" || top.kind === "closing_tag" || top.kind === "children";
  }

  private isGenericFunctionStart(): boolean {
    if (this.peek() !== "<") return false;

    let angleDepth = 1;
    let i = 1;
    while (i < 4096) {
      const c = this.peekAhead(i);
      if (c === "\0" || c === "\n" || c === "\r") return false;
      if (c === "\"" || c === "'" || c === "`") {
        const quote = c;
        i++;
        while (i < 4096) {
          const inner = this.peekAhead(i);
          if (inner === "\0" || inner === "\n" || inner === "\r") return false;
          if (inner === "\\") { i += 2; continue; }
          if (inner === quote) { i++; break; }
          i++;
        }
        continue;
      }
      if (c === "<") {
        angleDepth++;
        i++;
        continue;
      }
      if (c === ">") {
        // Ignore the `>` in function-type arrows inside a constraint.
        if (this.peekAhead(i - 1) === "=") {
          i++;
          continue;
        }
        angleDepth--;
        if (angleDepth === 0) {
          let j = i + 1;
          while (this.peekAhead(j) === " ") j++;
          if (this.peekAhead(j) !== "(") return false;

          let parenDepth = 1;
          let k = j + 1;
          while (k < 4096) {
            const param = this.peekAhead(k);
            if (param === "\0" || param === "\n" || param === "\r") return false;
            if (param === "\"" || param === "'" || param === "`") {
              const quote = param;
              k++;
              while (k < 4096) {
                const inner = this.peekAhead(k);
                if (inner === "\0" || inner === "\n" || inner === "\r") return false;
                if (inner === "\\") { k += 2; continue; }
                if (inner === quote) { k++; break; }
                k++;
              }
              continue;
            }
            if (param === "(") parenDepth++;
            else if (param === ")") {
              parenDepth--;
              if (parenDepth === 0) {
                let after = k + 1;
                while (this.peekAhead(after) === " ") after++;
                return this.peekAhead(after) === ":" || (this.peekAhead(after) === "=" && this.peekAhead(after + 1) === ">");
              }
            }
            k++;
          }
          return false;
        }
      }
      i++;
    }
    return false;
  }

  private isJsxTagStart(): boolean {
    if (!this.isFunx) return false;
    if (this.peek() !== "<") return false;

    // `<T>(value: T) => ...` is a generic function, not a JSX tag. Check the
    // full prefix because `.funx` files otherwise tokenize the parameters as
    // JSX attributes.
    if (this.isGenericFunctionStart()) return false;

    // Followed by tag name start, or / for closing tag, or > for fragment
    const next = this.peekAhead(1);
    if (!this.isAlpha(next) && next !== "_" && next !== "/" && next !== ">") {
      return false;
    }

    if (next === "/") return true;

    // Disambiguate from comparison operator (<) and generics
    const prevToken = this.tokens.length > 0 ? this.tokens[this.tokens.length - 1] : null;
    if (!prevToken) {
      return true;
    }

    const exprEndingTokens = new Set<TokenType>([
      TokenType.IDENTIFIER,
      TokenType.UPPER_IDENTIFIER,
      TokenType.NUMBER,
      TokenType.STRING,
      TokenType.RPAREN,
      TokenType.RBRACKET,
      TokenType.RBRACE,
      TokenType.TRUE,
      TokenType.FALSE,
      TokenType.UNDERSCORE,
    ]);

    if (exprEndingTokens.has(prevToken.type)) {
      return false;
    }

    return true;
  }

  private advanceWhitespaceNewline(): void {
    if (this.peek() === "\r") this.advance();
    if (this.peek() === "\n") this.advance();
    this.line++;
    this.column = 1;
    this.atLineStart = true;
  }

  private readJsxChildren(): void {
    const char = this.peek();

    if (char === "<") {
      if (this.matchAhead("</")) {
        this.emitToken(TokenType.JSX_CLOSING_TAG_OPEN, "</", 2);
        this.jsxStack.push({ kind: "closing_tag", hasTagName: false });
      } else {
        this.emitToken(TokenType.JSX_TAG_OPEN, "<", 1);
        this.jsxStack.push({ kind: "tag", hasTagName: false });
      }
      return;
    }

    if (char === "{") {
      this.emitToken(TokenType.LBRACE, "{", 1);
      this.braceStack.push("jsx_expr");
      this.jsxStack.push({ kind: "expr" });
      return;
    }

    const startPos = this.currentPosition();
    let text = "";
    while (!this.isAtEnd() && this.peek() !== "<" && this.peek() !== "{") {
      const c = this.advance();
      if (c === "\r") {
        if (this.peek() === "\n") {
          this.advance();
        }
        this.line++;
        this.column = 1;
        text += "\n";
      } else if (c === "\n") {
        this.line++;
        this.column = 1;
        text += "\n";
      } else {
        text += c;
      }
    }

    if (text.length > 0) {
      this.tokens.push({
        type: TokenType.JSX_TEXT,
        value: text,
        span: { start: startPos, end: this.currentPosition() },
      });
    }
  }

  private readJsxTag(top: { kind: "tag" | "closing_tag" | "children" | "expr"; hasTagName?: boolean }): void {
    const char = this.peek();

    // Whitespace (inline)
    if (char === " " || char === "\t") {
      this.advance();
      return;
    }

    // Newlines within tags
    if (char === "\r" || char === "\n") {
      this.advanceWhitespaceNewline();
      return;
    }

    // Comments within tags
    if (this.matchAhead("//")) {
      this.skipComment();
      return;
    }

    // Tag name
    if (!top.hasTagName) {
      if (char === ">") {
        // Empty fragment tag: <> or </>
        this.emitToken(TokenType.JSX_TAG_CLOSE, ">", 1);
        if (top.kind === "tag") {
          top.kind = "children";
        } else {
          this.jsxStack.pop();
          if (this.jsxStack.length > 0 && this.jsxStack[this.jsxStack.length - 1].kind === "children") {
            this.jsxStack.pop();
          }
        }
        return;
      }

      if (this.isAlpha(char) || char === "_") {
        const startPos = this.currentPosition();
        let name = "";
        while (!this.isAtEnd() && (this.isAlphaNumeric(this.peek()) || this.peek() === "_" || this.peek() === "-")) {
          name += this.advance();
        }
        top.hasTagName = true;
        const type = name[0] >= "A" && name[0] <= "Z" ? TokenType.UPPER_IDENTIFIER : TokenType.IDENTIFIER;
        this.tokens.push({
          type,
          value: name,
          span: { start: startPos, end: this.currentPosition() },
        });
        return;
      }

      throw new LexerError(`Expected tag name after '<', found '${char}'`, this.currentSpan(1));
    }

    // Member access in tag name (e.g. <Namespace.Component />)
    if (char === ".") {
      this.emitToken(TokenType.DOT, ".", 1);
      top.hasTagName = false;
      return;
    }

    // Self-closing slash close: '/>'
    if (this.matchAhead("/>")) {
      this.emitToken(TokenType.JSX_SLASH_CLOSE, "/>", 2);
      this.jsxStack.pop();
      return;
    }

    // Tag close: '>'
    if (char === ">") {
      this.emitToken(TokenType.JSX_TAG_CLOSE, ">", 1);
      if (top.kind === "tag") {
        top.kind = "children";
      } else {
        this.jsxStack.pop();
        if (this.jsxStack.length > 0 && this.jsxStack[this.jsxStack.length - 1].kind === "children") {
          this.jsxStack.pop();
        }
      }
      return;
    }

    // Equals: '='
    if (char === "=") {
      this.emitToken(TokenType.EQ, "=", 1);
      return;
    }

    // String attribute value: '"..."'
    if (char === '"') {
      this.readString();
      return;
    }

    // Embedded expression attribute value: '{...}'
    if (char === "{") {
      this.emitToken(TokenType.LBRACE, "{", 1);
      this.braceStack.push("jsx_expr");
      this.jsxStack.push({ kind: "expr" });
      return;
    }

    // Attribute name
    if (this.isAlpha(char) || char === "_" || char === "-") {
      const startPos = this.currentPosition();
      let attrName = "";
      while (
        !this.isAtEnd() &&
        (this.isAlphaNumeric(this.peek()) || this.peek() === "_" || this.peek() === "-" || this.peek() === ":")
      ) {
        attrName += this.advance();
      }
      this.tokens.push({
        type: TokenType.JSX_ATTRIBUTE_NAME,
        value: attrName,
        span: { start: startPos, end: this.currentPosition() },
      });
      return;
    }

    throw new LexerError(`Unexpected character '${char}' in JSX tag`, this.currentSpan(1));
  }
}
