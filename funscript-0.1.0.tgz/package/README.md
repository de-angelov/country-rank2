# FunScript

> A compact, indentation-based language that compiles to readable TypeScript for the Effect v4 ecosystem.

FunScript is a notation for building typed TypeScript programs with [Effect](https://effect.website),
[ts-pattern](https://github.com/gvergnaud/ts-pattern), and [Mutative](https://github.com/unadlib/mutative).
It keeps their semantics and emitted code visible, while making effects, schemas, pipelines, pattern
matching, and immutable updates less ceremonial.

**Status:** experimental compiler and tooling under active development.

<!-- GENERATED: project-facts -->
## Generated project facts

- Package: `funscript` `0.1.0`
- Runtime: Effect `^4.1.2`
- Source extensions: `.fun`, `.funx`
- Runnable checked examples: 21

The exact command surface is generated from the implementation in the [CLI reference](docs/reference/cli.md). The language catalogue used by editor hover help is generated in the [language reference](docs/reference/language.md).
<!-- /GENERATED: project-facts -->

## Why FunScript?

```funscript
export schema Shape =
  | Circle(radius: Number)
  | Rect(width: Number, height: Number)

export area = (shape: Shape) =>
  match shape
    | Circle(r) => Math.PI * r * r
    | Rect(w, h) => w * h
```

That becomes ordinary TypeScript built on `Data.TaggedEnum`, `Schema`, and `ts-pattern`.
The output remains readable, debuggable, and portable: FunScript does not hide a custom runtime
or standard library behind the generated code.

## What works today

- Compile `.fun` and `.funx` files to TypeScript and TSX.
- Type-check source with source-mapped diagnostics.
- Format FunScript source and use the formatter through Prettier.
- Run programs locally through the CLI.
- Use schemas, tagged unions, pattern matching, pipelines, effects, JSX, services, and the LSP.
- Integrate through the Vite plugin and the VS Code extension.

The exact CLI surface is generated from the implementation: see the [CLI reference](docs/reference/cli.md).
Package entry points are likewise generated in the [API reference](docs/reference/api.md).
For language rules accepted by the compiler, [the syntax guide](docs/syntax.md) is authoritative;
sections marked **Planned** describe future work. The generated [language catalogue](docs/reference/language.md)
comes from `src/lsp/docs.ts` and supplies editor hover help.

## Quick start from a checkout

```sh
git clone https://github.com/de-angelov/funscript.git
cd funscript
npm ci
npm run build

# Inspect the commands compiled from the current source.
node dist/cli/index.js --help

# Run a small example.
node dist/cli/index.js run examples/hello.fun
```

Use `npm run docs:generate` after changing the CLI catalogue or package exports. CI runs
`npm run docs:check` and fails if generated references are stale.

## Core ideas

- **Effect-first:** `effect { ... }` turns `<-` bindings into `Effect.gen` sequencing.
- **Schemas and data:** one `schema` declaration covers records, refinements, tagged unions,
  and type aliases.
- **Expression-oriented control flow:** `match` is exhaustive branching; `when` is the guard.
- **Immutable by default:** use record spreads for updates and explicit `mut` blocks when a
  structural-sharing draft is the clearest tool.
- **Escape hatch, not a second language:** use explicit raw `ts` blocks when TypeScript is the
  right boundary.

For the current, verified contract and runnable source examples, read the
[documentation map](docs/README.md).

## Examples

<!-- GENERATED: example-inventory -->
| [`examples/assemblyscript-numeric.fun`](examples/assemblyscript-numeric.fun) | `FunScript` |
| [`examples/assemblyscript-primes.fun`](examples/assemblyscript-primes.fun) | `FunScript` |
| [`examples/bank-account.fun`](examples/bank-account.fun) | `FunScript` |
| [`examples/fibonacci.fun`](examples/fibonacci.fun) | `FunScript` |
| [`examples/github-api-client.fun`](examples/github-api-client.fun) | `FunScript` |
| [`examples/greeter-service.fun`](examples/greeter-service.fun) | `FunScript` |
| [`examples/hello.fun`](examples/hello.fun) | `FunScript` |
| [`examples/js-ts-interop.fun`](examples/js-ts-interop.fun) | `FunScript` |
| [`examples/markdown-task-manager.fun`](examples/markdown-task-manager.fun) | `FunScript` |
| [`examples/order-fulfillment.fun`](examples/order-fulfillment.fun) | `FunScript` |
| [`examples/pipeline-helpers.fun`](examples/pipeline-helpers.fun) | `FunScript` |
| [`examples/reactive-widget.funx`](examples/reactive-widget.funx) | `FunScript JSX` |
| [`examples/rest-api-server.fun`](examples/rest-api-server.fun) | `FunScript` |
| [`examples/shapes.fun`](examples/shapes.fun) | `FunScript` |
| [`examples/solid-demo/domain.fun`](examples/solid-demo/domain.fun) | `FunScript` |
| [`examples/solid-demo/solid-in-funscript.fun`](examples/solid-demo/solid-in-funscript.fun) | `FunScript` |
| [`examples/sqlite-repository.fun`](examples/sqlite-repository.fun) | `FunScript` |
| [`examples/todo-dashboard.funx`](examples/todo-dashboard.funx) | `FunScript JSX` |
| [`examples/todo-http.fun`](examples/todo-http.fun) | `FunScript` |
| [`examples/todo-service.fun`](examples/todo-service.fun) | `FunScript` |
| [`examples/ts-schema-validation.fun`](examples/ts-schema-validation.fun) | `FunScript` |
<!-- /GENERATED: example-inventory -->

## Development

```sh
npm ci
npm run build
npm run fmt:check
npm run prettier:check
npm test -- --reporter=basic
```

For the CI-equivalent local gate, run `npm run pr:check`. It builds, verifies generated docs,
checks formatting, and runs the test suite. The GitHub workflow uses the same order and rejects
stale generated references.

## Project map

```text
src/cli/          CLI commands and command catalogue
src/compiler/     Static checking and compilation
src/emitter/      TypeScript and TSX generation
src/formatter/    Formatter and Prettier plugin
src/lsp/          Language Server Protocol support
src/plugins/      Vite integration
editors/vscode/   VS Code extension
examples/         Runnable examples, showcases, and applications
docs/             Language, tooling, and generated references
tests/            Compiler, CLI, formatter, LSP, and integration coverage
```

## Documentation

- [CLI reference](docs/reference/cli.md) — generated from the command catalogue.
- [Package entry points](docs/reference/api.md) — generated from `package.json` exports.
- [Language syntax guide](docs/syntax.md) — authoritative reference for implemented language rules; planned material is labeled.
- [Language catalogue](docs/reference/language.md) — generated from `src/lsp/docs.ts` and used for language-server hover help.
- [Example inventory](docs/reference/examples.md) — generated from the runnable example tree.
- [Documentation map](docs/README.md) — separates current verified docs from proposals/history.
- [Tooling guide](docs/tooling.md) — use FunScript in a normal Node project.
- [Language compatibility policy](docs/compatibility.md) — compatibility guarantees, deprecation lifecycle, and pipeline ambiguity policy.
- [CI and release operations](docs/ci-release.md) — maintainer workflow.

## Scope and non-goals

FunScript is not a replacement runtime, package manager, framework, or test runner. Use the
TypeScript ecosystem directly for those concerns: Effect for runtime services, Vite for web
development, Vitest for tests, and npm/pnpm/Bun for packages. The planned `new`, `dev`,
`preview`, `test`, `add`, and `doctor` CLI wrappers are not currently implemented.

## License

License selection is pending.

### Numeric AssemblyScript blocks

A top-level `as { ... }` block can define numeric WebAssembly kernels. Exported
functions are available locally in the FunScript module:

```funscript
as {
  export function square(value: f64): f64 { return value * value; }
}

export result = square(12)
export safeResult = square.effect(12)
```

The current boundary supports explicit `i32`, `u32`, `f32`, and `f64` parameters
and return values. Strings, arrays, objects, 64-bit integers, imported modules,
and non-function exports are not supported. Wasm integer operations and numeric
conversions follow WebAssembly semantics; traps throw JavaScript exceptions and
can be handled explicitly with Effect. Kernels compile when FunScript compiles,
and each block instantiates Wasm synchronously on its first call. Each
function also has a lazy `functionName.effect(...)` companion that returns an
Effect: it checks inputs before calling Wasm and reports tagged `WasmInputError`,
`WasmTrapError`, or `WasmInitializationError` failures. Integer inputs must be whole numbers in range;
floating-point inputs must be finite, and `f32` inputs must be in range (they
are still rounded to 32-bit precision). Direct calls retain Wasm conversion and
trap behavior, including throwing initialization failures. A successfully initialized
instance is reused; a failed initialization is retried on the next call. Calls
cross a JS/Wasm boundary, so benchmark real workloads before assuming a speedup.
Compilation of files containing these blocks is asynchronous: use
`Effect.runPromise(compileString(...))` rather than `Effect.runSync`. Effect
service generation and automatic currying are not provided.

See [the numeric and Effect example](examples/assemblyscript-numeric.fun) and
[the prime-counting example](examples/assemblyscript-primes.fun) for complete
programs.

See [optional arguments and Effect Option](docs/optional-arguments.md) for
the omission, default, and explicit Option rules and migration guidance.
