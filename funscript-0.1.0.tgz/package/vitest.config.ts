import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    exclude: ["slopboss/workspaces/**", "funscript-board/**"],
  },
});
